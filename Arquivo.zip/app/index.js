require('dotenv').config();
const tdlib = require('./tdlib');

(async () => {
  await tdlib.init();
})();