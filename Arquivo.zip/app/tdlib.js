const { createClient } = require('tdweb');
const { sendToChatwoot, sendFromChatwoot } = require('./chatwoot');
const readline = require('readline-sync');

let client;

async function init() {
  client = createClient({
    apiId: process.env.TELEGRAM_API_ID,
    apiHash: process.env.TELEGRAM_API_HASH,
    databaseDirectory: '_td_database',
    filesDirectory: '_td_files',
  });

  client.on('update', async (update) => {
    if (update['@type'] === 'updateNewMessage') {
      const message = update.message;
      const content = message.content;
      const chatId = message.chat_id;

      if (content['@type'] === 'messageText') {
        const text = content.text.text;
        console.log(`[Telegram] ${chatId}: ${text}`);
        await sendToChatwoot(chatId, text);
      }
    }
  });

  await client.send({
    '@type': 'setTdlibParameters',
    parameters: {
      use_test_dc: false,
      database_directory: '_td_database',
      files_directory: '_td_files',
      use_message_database: true,
      api_id: process.env.TELEGRAM_API_ID,
      api_hash: process.env.TELEGRAM_API_HASH,
      system_language_code: 'pt',
      device_model: 'Server',
      application_version: '1.0',
      enable_storage_optimizer: true
    }
  });

  await client.send({ '@type': 'checkDatabaseEncryptionKey', key: '' });
  let state = await client.send({ '@type': 'getAuthorizationState' });

  while (state['@type'] !== 'authorizationStateReady') {
    if (state['@type'] === 'authorizationStateWaitPhoneNumber') {
      await client.send({ '@type': 'setAuthenticationPhoneNumber', phone_number: process.env.TELEGRAM_PHONE });
    } else if (state['@type'] === 'authorizationStateWaitCode') {
      const code = readline.question('Digite o código de verificação do Telegram: ');
      await client.send({ '@type': 'checkAuthenticationCode', code });
    } else if (state['@type'] === 'authorizationStateWaitPassword') {
      const password = readline.question('Digite sua senha em duas etapas: ', { hideEchoBack: true });
      await client.send({ '@type': 'checkAuthenticationPassword', password });
    }
    state = await client.send({ '@type': 'getAuthorizationState' });
  }

  console.log('Autenticado com sucesso no Telegram!');

  // Exemplo: enviar mensagem de teste
  // await sendTelegramMessage(123456789, 'Teste de envio pelo Chatwoot');
}

async function sendTelegramMessage(chatId, message) {
  if (!client) return;
  await client.send({
    '@type': 'sendMessage',
    chat_id: chatId,
    input_message_content: {
      '@type': 'inputMessageText',
      text: { '@type': 'formattedText', text: message },
    }
  });
}

module.exports = { init, sendTelegramMessage };