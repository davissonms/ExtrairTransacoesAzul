const axios = require('axios');
const { sendTelegramMessage } = require('./tdlib');

async function sendToChatwoot(source_id, content) {
  try {
    const response = await axios.post(`${process.env.CHATWOOT_BASE_URL}/api/v1/accounts/1/conversations`, {
      source_id: String(source_id),
      inbox_identifier: process.env.INBOX_IDENTIFIER,
      contact: {
        name: `Contato ${source_id}`
      },
      message: {
        content: content
      }
    }, {
      headers: {
        'api_access_token': process.env.CHATWOOT_TOKEN,
        'Content-Type': 'application/json'
      }
    });

    console.log(`[Chatwoot] Mensagem enviada para inbox.`);
  } catch (error) {
    console.error('[Chatwoot] Erro ao enviar mensagem:', error.response?.data || error.message);
  }
}

async function sendFromChatwoot(chatId, message) {
  await sendTelegramMessage(chatId, message);
}

module.exports = { sendToChatwoot, sendFromChatwoot };
